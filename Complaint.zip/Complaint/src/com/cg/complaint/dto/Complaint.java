package com.cg.complaint.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="complaint")
public class Complaint 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="com_seq")
	@SequenceGenerator(name="com_seq",sequenceName="hibernate_seq")
	private Integer complaintid;
	private Integer accountid;
	private String branchcode;
	private String emailid;
	private String category;
	private String description;
	private String priority;
	private String status;
	
	
	public Integer getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(Integer complaintid) {
		this.complaintid = complaintid;
	}
	public Integer getAccountid() {
		return accountid;
	}
	public void setAccountid(Integer accountid) {
		this.accountid = accountid;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
