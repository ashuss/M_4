package com.cg.complaint.service;

import java.util.List;

import com.cg.complaint.dto.Complaint;

public interface IComplaintService 
{
	public void addComplaint(Complaint com);
	public List<Complaint> showComplaintById(int comId);
}
