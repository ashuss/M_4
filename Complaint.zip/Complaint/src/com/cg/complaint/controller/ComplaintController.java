package com.cg.complaint.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.complaint.dto.Complaint;
import com.cg.complaint.service.IComplaintService;



@Controller
public class ComplaintController 
{
	@Autowired
	IComplaintService cSer;
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String RaiseCom(@ModelAttribute("my") Complaint com,
			Map<String,Object> model)
	{
		List<String> myCat=new ArrayList<>();
		myCat.add("Internet Banking");
		myCat.add("General Banking");
		myCat.add("Others");
		model.put("catg", myCat);
		return "RaiseComplaintPage";
	}
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String addEmployee(@ModelAttribute("my") Complaint com)
	{
		cSer.addComplaint(com);
		
		return "success";
	}
	@RequestMapping(value="check",method=RequestMethod.GET)
	public String Login()
	{
		return "CheckStatus";
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showATrainee1(@RequestParam("cid") int id)
	{
		List<Complaint> myAllData1=cSer.showComplaintById(id);
		return new ModelAndView("retrievebyId", "temp", myAllData1);
	}
	
	
}
