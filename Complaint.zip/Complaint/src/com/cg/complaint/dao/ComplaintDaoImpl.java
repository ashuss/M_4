package com.cg.complaint.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.complaint.dao.IComplaintDao;
import com.cg.complaint.dto.Complaint;


@Repository("cDao")
public class ComplaintDaoImpl implements IComplaintDao
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public void addComplaint(Complaint com) 
	{
		entitymanager.persist(com);
		entitymanager.flush();
		
	}

	@Override
	public List<Complaint> showComplaintById(int comId)
	{
		Query queryOne=entitymanager.createQuery("Select c FROM Complaint c WHERE complaintid=:cId");
		queryOne.setParameter("cId", comId);
		List<Complaint> myList=queryOne.getResultList();
	    return myList;
	}

}
