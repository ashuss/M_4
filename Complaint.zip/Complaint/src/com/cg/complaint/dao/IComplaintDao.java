package com.cg.complaint.dao;

import java.util.List;

import com.cg.complaint.dto.Complaint;



public interface IComplaintDao 
{
	public void addComplaint(Complaint com);
	public List<Complaint> showComplaintById(int comId);
}
